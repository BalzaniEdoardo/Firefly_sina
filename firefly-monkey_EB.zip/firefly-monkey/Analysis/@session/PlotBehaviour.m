%% plot behaviour
function PlotBehaviour(this,plot_type,prs)
    behv = this.behaviours;
    PlotBehaviour(behv,plot_type,prs);
end