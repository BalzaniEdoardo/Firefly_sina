%% analyse behaviour
function AnalyseBehaviour(this,prs)
    this.stats = AnalyseBehaviour(this.trials,prs);
end