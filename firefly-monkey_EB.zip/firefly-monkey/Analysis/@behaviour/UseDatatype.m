%% change datatype (to save memory)
function UseDatatype(this,data_type)
    UseDatatype_behv(this,data_type);
end